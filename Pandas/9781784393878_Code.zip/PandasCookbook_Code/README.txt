All Chapters have codes
